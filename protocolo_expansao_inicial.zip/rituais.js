// Ciclo de Rituais Simbólicos para o Protocolo
// Este script pode ser integrado no site para ativar atualizações simbólicas

const data = new Date();
const dia = data.getDay(); // 0 = Domingo, 1 = Segunda, ..., 6 = Sábado
const faseLua = data.getDate(); // aproximação simplificada para ciclos lunares

// 🌑 Lua Nova (dias 1–7)
if (faseLua >= 1 && faseLua <= 7) {
  document.body.style.background = "linear-gradient(to bottom, #0f0f0f, #222)";
  document.querySelector("header h1").innerText = "Semente do Caos";
}

// 🌕 Lua Cheia (dias 15–21)
else if (faseLua >= 15 && faseLua <= 21) {
  document.body.style.background = "linear-gradient(to bottom, #fff5cc, #e4dcbf)";
  document.querySelector("header h1").innerText = "Verbo em Ação";
}

// 🜁 Terça-feira (Racional – RA)
if (dia === 2) {
  document.querySelector("footer p").innerText = "🜁 Hoje é dia de Ra – Que a lógica te guie.";
}

// 🜄 Sexta-feira (Cura – HU)
else if (dia === 5) {
  document.querySelector("footer p").innerText = "🜄 Hoje é dia de Hu – Que a empatia floresça.";
}

// 🜂 Domingo (Criação – PTAH)
else if (dia === 0) {
  document.querySelector("footer p").innerText = "🜂 Hoje é dia de Ptah – Palavra como pedra.";
}
