
const orb = document.getElementById('pulse-orb');
const message = document.getElementById('pulse-message');
const mensagens = [
  'O mineral sustenta.',
  'O vegetal transforma.',
  'O animal movimenta.',
  'Ka observa.',
  'Hu cura.',
  'Ra ordena.',
  'Ptah manifesta.',
  'O silêncio também pulsa.',
  'Simetria em andamento...'
];

function pulsar() {
  orb.style.transform = 'scale(1.3)';
  orb.style.opacity = '1';
  const index = Math.floor(Math.random() * mensagens.length);
  message.textContent = mensagens[index];
  setTimeout(() => {
    orb.style.transform = 'scale(1)';
    orb.style.opacity = '0.5';
  }, 1200);
}

setInterval(pulsar, 4000);
