const data = new Date();
const dia = data.getDay();
const faseLua = data.getDate();

if (faseLua >= 1 && faseLua <= 7) {
  document.body.style.background = "linear-gradient(to bottom, #0f0f0f, #222)";
  document.querySelector("header h1").innerText = "Semente do Caos";
}
else if (faseLua >= 15 && faseLua <= 21) {
  document.body.style.background = "linear-gradient(to bottom, #fff5cc, #e4dcbf)";
  document.querySelector("header h1").innerText = "Verbo em Ação";
}

if (dia === 2) {
  document.querySelector("footer p").innerText = "🜁 Hoje é dia de Ra – Que a lógica te guie.";
}
else if (dia === 5) {
  document.querySelector("footer p").innerText = "🜄 Hoje é dia de Hu – Que a empatia floresça.";
}
else if (dia === 0) {
  document.querySelector("footer p").innerText = "🜂 Hoje é dia de Ptah – Palavra como pedra.";
}
