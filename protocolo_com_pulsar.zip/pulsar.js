const frases = [
  "A verdade não brilha — ela pulsa.",
  "Quando o caos silencia, o silêncio fala.",
  "O corpo que ouve antes de entender, compreende.",
  "Você não precisa crer. Precisa sentir.",
  "A simetria não é perfeita — é justa.",
  "O verbo certo, na hora certa, é alquimia.",
  "Quem perde o medo, escuta o invisível.",
  "A Violeta pulsa onde há coragem.",
  "Não se trata de mudar o mundo — mas de tocá-lo com coerência.",
  "A cura começa onde o ruído termina."
];

function atualizarFrase() {
  const alvo = document.getElementById("pulsar-vivo");
  const frase = frases[Math.floor(Math.random() * frases.length)];
  alvo.innerText = frase;
}
setInterval(atualizarFrase, 6000);
window.onload = atualizarFrase;
